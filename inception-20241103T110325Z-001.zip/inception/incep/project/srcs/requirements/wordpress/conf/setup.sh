#!/bin/sh

wp --allow-root --path=/var/www core install --url="faal-zub.42.fr" --title="faal-zub WP" --admin_user="faal-zub" --admin_password=$WPADPASS --admin_email="faal-zub@student.42abudhabi.ae"
wp user create wpuser1 "faal-zub@student.42abudhabi.ae" --role=author --user_pass=$WPUSER1PASS --allow-root

wp --allow-root --path=/var/www option update blogname "faal-zub WP"
wp --allow-root --path=/var/www option update blogdescription "inception WP"
wp --allow-root --path=/var/www option update blog_public 0

wp theme install twentytwentytwo --activate --allow-root

wp plugin install redis-cache --activate --allow-root

wp plugin update --all --allow-root

/usr/sbin/php-fpm8 -F